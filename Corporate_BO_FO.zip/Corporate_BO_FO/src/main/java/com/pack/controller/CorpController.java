package com.pack.controller;

import java.util.List;

import javax.validation.Valid;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.pack.exception.CustomException;
import com.pack.model.Corp;
import com.pack.service.CorpService;

@Controller
public class CorpController {
	final static Logger logger = LogManager.getLogger(CorpController.class);
	@Autowired
	CorpService corpService;

	@RequestMapping("/")
	public String showIndex() {
		return "homePageAdmin";
	}

	@RequestMapping("/corpEntryController")
	public String showCorpEntry() {
		return "corpEntry";
	}

	@RequestMapping("/addCorpController")
	public String addCorp(Model m) {
		logger.info("into add");
		m.addAttribute("corp", new Corp());
		return "addCorp";
	}

	@RequestMapping(value = "/addCorpForm", method = RequestMethod.POST)
	public String addCorps(@Valid @ModelAttribute("corp") Corp corp, BindingResult br) {
		if (br.hasErrors()) {
			return "addCorp";
		}
		logger.info("into added corporate");
		if (corpService.saveCorp(corp))
			return "addCorpSuccess";
		else
			return "failure";

	}

	@RequestMapping("/viewCorpController")
	public String viewCorp(Model m) {
		String s = "Y";
		List<Corp> list = corpService.viewAll(s);
		m.addAttribute("list", list);
		logger.info("view corporate");
		return "viewCorp";
	}

	@RequestMapping(value = "/modifyCorpController")
	public String update(@RequestParam("corpId") int id, Model m) {
		Corp corp = null;
		String page = null;
		try {
			if (corpService.getCorpById(id).isPresent()) {
				corp = corpService.getCorpById(id).get();
				m.addAttribute("modifycorp", corp);
				page = "modifyCorp";
				logger.info("modify corporate");

			} else if (corpService.getCorpById(id).isEmpty()) {
				System.out.println("emp " + corp);
				throw new CustomException();

			}
		} catch (CustomException e) {
			m.addAttribute("exception", e);
			page = "ExceptionPage";

		}

		return page;

	}

	@RequestMapping(value = "/modifyCorpDB")
	public String modify(Corp corp) {
		if (corpService.saveCorp(corp))
			return "redirect:/viewCorpController";
		else
			return "failure";

	}

	@RequestMapping(value = "/deleteCorpController")
	public String delete(@RequestParam("corpId") int id, Model m) {

		String page = null;
		try {
			if (corpService.getCorpById(id).isPresent()) {
				corpService.deleteCorpById(id);
				logger.info("deleted corporate");
				page = "redirect:/viewCorpController";

			} else if (corpService.getCorpById(id).isEmpty()) {
				throw new CustomException();

			}
		} catch (CustomException e) {
			m.addAttribute("exception", e);
			page = "ExceptionPage";

		}

		return page;

	}

}

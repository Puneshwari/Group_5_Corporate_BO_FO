package com.pack.controller;

import java.security.Principal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.pack.model.User;
import com.pack.service.UserService;

@Controller
@SessionAttributes("login")
public class HomeController {

	@Autowired
	UserService userService;

	@ModelAttribute("login")
	public User gotoHomePage() {
		return new User();
	}

	@RequestMapping("/login")
	public String login(Model m) {
		m.addAttribute("user", new User());
		return "index";
	}

	@GetMapping("/admin")
	public String admin() {
		return "homePageAdmin";
	}

	@GetMapping("/user")
	public String user(Principal principal, Model m) {
		String username = principal.getName();
		User user = userService.getUserByLoginId(username).get();
		int cid = user.getCorpId().getCorpId();
		m.addAttribute("corpId", cid);
		return "homePageUser";
	}

	@RequestMapping("/AccountSummarys")
	public String viewCorp2(@RequestParam("corpId") String id, Model m) {

		m.addAttribute("corpId", id);
		return "showSummary";
	}

	@GetMapping("/logout")
	public String logout() {
		return "logout";
	}

	@RequestMapping("/AccountDetails")
	public String viewAccount(@RequestParam("accNumber") String id, Model m) {

		m.addAttribute("accNumber", id);
		return "accountDetail";
	}

}
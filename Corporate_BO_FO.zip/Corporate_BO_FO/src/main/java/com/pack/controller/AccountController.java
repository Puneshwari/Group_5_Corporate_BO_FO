package com.pack.controller;

import java.util.List;

import javax.validation.Valid;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
//import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.pack.exception.CustomException;
import com.pack.model.Account;
import com.pack.service.AccountService;

@Controller
public class AccountController {

	final static Logger logger = LogManager.getLogger(CorpController.class);
	@Autowired
	AccountService accountService;

	@RequestMapping("/accountEntryController")
	public String showAccountEntry() {
		return "accountEntry";
	}

	@RequestMapping("/addAccountController")
	public String addAccount(Model m) {
		logger.info("into add account");
		m.addAttribute("account", new Account());
		return "addAccount";
	}

	@RequestMapping(value = "/addAccountForm", method = RequestMethod.POST)
	public String addAcc(@Valid @ModelAttribute("account") Account account, BindingResult br) {
		if (br.hasErrors()) {
			return "addAccount";
		}
		logger.info("into added account");
		if (accountService.saveAccount(account))
			return "addAccountSuccess";
		else
			return "failure";

	}

	@RequestMapping("/viewAccountController")
	public String viewCorp(Model m) {
		String s = "Y";
		List<Account> list = accountService.viewAll(s);
		m.addAttribute("list", list);
		logger.info("view account");
		return "viewAccount";
	}

	@RequestMapping(value = "/deleteAccountController")
	public String delete(@RequestParam("accNumber") String accNumber, Model m) {

		String page = null;
		try {
			if (accountService.getAccountByAccNumber(accNumber).isPresent()) {
				accountService.deleteCorpByAccNumber(accNumber);
				logger.info("deleted account");
				page = "redirect:/viewAccountController";

			} else if (accountService.getAccountByAccNumber(accNumber).isEmpty()) {
				throw new CustomException();

			}
		} catch (CustomException e) {
			m.addAttribute("exception", e);
			page = "ExceptionPage";

		}

		return page;

	}

}

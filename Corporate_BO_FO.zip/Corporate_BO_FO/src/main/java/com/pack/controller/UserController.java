package com.pack.controller;

import java.util.List;

import javax.validation.Valid;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.jdbc.core.BeanPropertyRowMapper;
//import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.pack.exception.CustomException;
import com.pack.model.User;
import com.pack.service.UserService;

@Controller
public class UserController {

	final static Logger logger = LogManager.getLogger(CorpController.class);
	@Autowired
	UserService userService;

	@RequestMapping("/userEntryController")
	public String showUserEntry() {
		return "userEntry";
	}

	@RequestMapping("/addUserController")
	public String addUser(Model m) {
		logger.info("into add");
		m.addAttribute("user", new User());
		return "addUser";
	}

	@RequestMapping(value = "/addUserForm", method = RequestMethod.POST)
	public String addStudent(@Valid @ModelAttribute("user") User user, BindingResult br) {
		if (br.hasErrors()) {
			return "addUser";
		}
		logger.info("into added user");
		if (userService.saveUser(user))
			return "addUserSuccess";
		else
			return "failure";

	}

	@RequestMapping("/viewUserController")
	public String viewCorp(Model m) {
		String s = "Y";
		List<User> list = userService.viewAll(s);
		m.addAttribute("list", list);
		logger.info("view user");
		return "viewUser";
	}

	@RequestMapping(value = "/modifyUserController")
	public String edit(@RequestParam("username") String username, Model m) {
		User user = null;
		String page = null;
		try {
			System.out.println("updated in process");
			if (userService.getUserByLoginId(username).isPresent()) {
				System.out.println("updated in process stage 2");
				user = userService.getUserByLoginId(username).get();
				System.out.println("updated in process stage 3");
				m.addAttribute("modifyuser", user);
				page = "modifyUser";
				logger.info("modify user");

			} else if (userService.getUserByLoginId(username).isEmpty()) {
				System.out.println("emp " + user);
				throw new CustomException();

			}
		} catch (CustomException e) {
			m.addAttribute("exception", e);
			page = "ExceptionPage";

		}

		return page;
	}

	@RequestMapping(value = "/modifyUserDB")
	public String modify(User user) {
		if (userService.saveUser(user))
			return "redirect:/viewUserController";
		else
			return "failure";

	}

	@RequestMapping(value = "/deleteUserController")
	public String delete(@RequestParam("username") String loginId, Model m) {

		String page = null;
		try {
			System.out.println("deleted in process");
			if (userService.getUserByLoginId(loginId).isPresent()) {
				System.out.println("delete in process stage 2");
				userService.deleteUserByLoginId(loginId);
				logger.info("deleted user");
				page = "redirect:/viewUserController";

			} else if (userService.getUserByLoginId(loginId).isEmpty()) {
				throw new CustomException();

			}
		} catch (CustomException e) {
			m.addAttribute("exception", e);
			page = "ExceptionPage";

		}

		return page;

	}

}

package com.pack.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pack.model.User;
import com.pack.repository.UserRepository;

@Service
public class UserService {

	@Autowired
	UserRepository userRepo;

	public boolean saveUser(User user) {
		userRepo.save(user);
		return true;

	}

	public List<User> viewAll(String s) {
		return userRepo.findByStatus(s);
	}

	public Optional<User> getUserByLoginId(String id) {
		return userRepo.findByUsername(id);

	}

	public void deleteUserByLoginId(String id) {
		userRepo.updateUser(id);

	}

	public List<User> getUserByLoginId(String username, String password) {
		// TODO Auto-generated method stub
		return userRepo.findByUsernameAndPassword(username, password);
	}

}

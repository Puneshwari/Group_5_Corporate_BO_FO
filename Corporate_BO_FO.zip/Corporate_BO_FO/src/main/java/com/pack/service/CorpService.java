package com.pack.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pack.model.Corp;
import com.pack.repository.CorpRepository;

@Service

public class CorpService {
	@Autowired
	CorpRepository corpRepo;

	public boolean saveCorp(Corp corp) {
		corpRepo.save(corp);
		return true;

	}

	public List<Corp> viewAll(String s) {
		return corpRepo.findByStatus(s);
	}

	public Optional<Corp> getCorpById(int id) {
		return corpRepo.findById(id);

	}

	public void deleteCorpById(int id) {
		corpRepo.updateCorp(id);

	}

}

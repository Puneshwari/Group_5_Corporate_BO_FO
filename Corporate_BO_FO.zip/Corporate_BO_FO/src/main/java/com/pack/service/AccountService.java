package com.pack.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pack.model.Account;
import com.pack.repository.AccountRepository;

@Service

public class AccountService {
	@Autowired
	AccountRepository accountRepo;

	public boolean saveAccount(Account account) {
		accountRepo.save(account);
		return true;

	}

	public List<Account> viewAll(String s) {
		return accountRepo.findByStatus(s);
	}

	
	  public Optional<Account> getAccountByAccNumber(String id) { 
		  return accountRepo.findByAccNumber(id);
	 
	  }
	 

	
	  public void deleteCorpByAccNumber(String id) { 
		  accountRepo.updateAccount(id);
	  
	  }
	 

}

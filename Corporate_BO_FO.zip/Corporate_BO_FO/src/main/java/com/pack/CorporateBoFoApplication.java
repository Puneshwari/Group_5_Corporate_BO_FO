package com.pack;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CorporateBoFoApplication {

	public static void main(String[] args) {
		SpringApplication.run(CorporateBoFoApplication.class, args);
	}

}

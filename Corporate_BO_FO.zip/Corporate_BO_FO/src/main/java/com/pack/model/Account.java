package com.pack.model;

import javax.persistence.Entity;
//import javax.persistence.GeneratedValue;
//import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
//import javax.persistence.JoinTable;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import javax.validation.constraints.NotEmpty;
@Entity
@Table(name = "Account")
public class Account {

	@Id
	@NotEmpty(message = "Required section")
	String accNumber;

	@NotEmpty(message = "Required section")
	String accName;


	String accBranch;
	String accCurrency;

	@NotEmpty(message = "Required section")
	String accBalance;

	String status = "Y";
	
	@ManyToOne
	@JoinColumn(name="corpId",referencedColumnName = "corpId")
	Corp corpsi;

	

	

	public Corp getCorpsi() {
		return corpsi;
	}

	public void setCorpsi(Corp corpsi) {
		this.corpsi = corpsi;
	}

	public String getAccNumber() {
		return accNumber;
	}

	public void setAccNumber(String accNumber) {
		this.accNumber = accNumber;
	}

	public String getAccName() {
		return accName;
	}

	public void setAccName(String accName) {
		this.accName = accName;
	}

	public String getAccBranch() {
		return accBranch;
	}

	public void setAccBranch(String accBranch) {
		this.accBranch = accBranch;
	}

	public String getAccCurrency() {
		return accCurrency;
	}

	public void setAccCurrency(String accCurrency) {
		this.accCurrency = accCurrency;
	}

	public String getAccBalance() {
		return accBalance;
	}

	public void setAccBalance(String accBalance) {
		this.accBalance = accBalance;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Account(String accNumber, String accName, String accBranch, String accCurrency, String accBalance) {
		// TODO Auto-generated constructor stub
		this.accNumber = accNumber;
		this.accName = accName;
		this.accBranch = accBranch;
		this.accCurrency = accCurrency;
		this.accBalance = accBalance;
	}

	public Account() {
		// TODO Auto-generated constructor stub
	}
	

}

package com.pack.model;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;

@Entity
@Table(name = "Corp")
public class Corp {
	public Corp(int corpId, @NotEmpty(message = "Required section") String corpName,
			@NotEmpty(message = "Required section") String corpAddress,
			@Pattern(regexp = "([789][0-9]{9})", message = "Enter valid phone number") String corpPhone, String status,
			List<User> user, List<Account> account) { // a
		super();
		this.corpId = corpId;
		this.corpName = corpName;
		this.corpAddress = corpAddress;
		this.corpPhone = corpPhone;
		this.status = status;
		this.user = user;
		this.account = account; // a
	}

	public Corp() {

	}

	public Corp(String corpName, String corpAddress, String corpPhone) {
		this.corpName = corpName;
		this.corpAddress = corpAddress;
		this.corpPhone = corpPhone;
	}

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	int corpId;

	@NotEmpty(message = "Required section")
	String corpName;

	@NotEmpty(message = "Required section")
	String corpAddress;

	@Pattern(regexp = "([789][0-9]{9})", message = "Enter valid phone number")
	String corpPhone;

	String status = "Y";

	@OneToMany(mappedBy = "corpId", cascade = CascadeType.ALL)
	List<User> user;

	@OneToMany(mappedBy = "corpsi", cascade = CascadeType.ALL)
	List<Account> account; // A

	public List<Account> getAccount() {
		return account;
	}

	public void setAccount(List<Account> account) {
		this.account = account;
	}

	public List<User> getUser() {
		return user;
	}

	public void setUser(List<User> user) {
		this.user = user;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public int getCorpId() {
		return corpId;
	}

	public void setCorpId(int corpId) {
		this.corpId = corpId;
	}

	public String getCorpName() {
		return corpName;
	}

	public void setCorpName(String corpName) {
		this.corpName = corpName;
	}

	public String getCorpAddress() {
		return corpAddress;
	}

	public void setCorpAddress(String corpAddress) {
		this.corpAddress = corpAddress;
	}

	public String getCorpPhone() {
		return corpPhone;
	}

	public void setCorpPhone(String corpPhone) {
		this.corpPhone = corpPhone;
	}
}

package com.pack.repository;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.pack.model.Account;

@Repository
public interface AccountRepository extends JpaRepository<Account, Integer> {

	public List<Account> findByStatus(String status);

	public Optional<Account> findByAccNumber(String id);
	
	@Transactional
	@Modifying
	@Query("update Account set status='N' where accNumber = :id")
	public void updateAccount(@Param("id") String accNumber);

	

	

}

package com.pack.repository;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.pack.model.User;

@Repository
public interface UserRepository extends JpaRepository<User, Integer> {

	public List<User> findByStatus(String status);

	Optional<User> findByUsername(String username);

	@Transactional
	@Modifying
	@Query("update User set status='N' where username = :id")
	public void updateUser(@Param("id") String username);

	public List<User> findByUsernameAndPassword(String username, String password);

}

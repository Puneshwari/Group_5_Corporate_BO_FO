package com.pack.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.pack.model.Corp;

@Repository
public interface CorpRepository extends JpaRepository<Corp, Integer> {

	public List<Corp> findByStatus(String status);

	@Transactional
	@Modifying
	@Query("update Corp set status='N' where corpId = :id")
	public void updateCorp(@Param("id") int corpId);

}

package com.pack;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.annotation.Rollback;

import com.pack.model.Account;
import com.pack.repository.AccountRepository;

@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
@Nested
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class AccountTest {
	@Autowired
	AccountRepository accountRepository;

	static Account c;

	@BeforeAll
	static void setUpBeforeClass() throws Exception {

		c = new Account("vir1", "Virtusa", "Sakinaka", "Dollar", "5678");

	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
	}

	@Test
	@Order(1)
	@Rollback(false)
	public void saveCorpTest() {

		// actual result
		accountRepository.save(c);

		Assertions.assertNotNull(c.getAccNumber());

	}

}

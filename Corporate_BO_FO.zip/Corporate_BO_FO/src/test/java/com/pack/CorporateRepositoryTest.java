package com.pack;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;

import java.util.List;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.annotation.Rollback;

import com.pack.model.Corp;
import com.pack.repository.CorpRepository;

@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
@Nested
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class CorpRepositoryTest {

	@Autowired
	CorpRepository corpRepository;
	// String s = "h";
	static Corp c;
	static Corp c1;
	static int id;

	@BeforeAll
	static void setUpBeforeClass() throws Exception {

		c = new Corp("Virtusa", "indore", "9987586153");
		c1 = new Corp("Virtusa", "indore", "9987586153");
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
	}

	@Test
	@Order(1)
	@Rollback(false)
	public void saveCorpTest() {

		// actual result
		corpRepository.save(c);
		corpRepository.save(c1);
		System.out.println(c.getCorpId());
		id = c.getCorpId();
		Assertions.assertNotNull(c.getCorpId());

	}

	@Test
	@Order(2)
	public void findByIdTest() {
		Corp cor = corpRepository.findById(id).get();
		System.out.println("hello Id");
		Assertions.assertEquals("Virtusa", cor.getCorpName());
	}

	@Test
	@Order(3)
	// @Rollback(false)
	public void findByStatusTest() {

		List<Corp> o = corpRepository.findByStatus(c.getStatus());
		// Assertions.assertNotNull(o);

		// assertThat(o).asList().hasSameSizeAs(expected);
		assertThat(o).asList().hasSizeGreaterThan(1);

	}

}

//	@Nested
//	@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
//	class AccountTest {
//		@Autowired
//		AccountRepository accountRepository;
//
//		static Account c;
//
//		@BeforeAll
//		static void setUpBeforeClass() throws Exception {
//
//			c = new Account("vir1", "Virtusa", "Sakinaka", "Dollar", "5678");
//
//		}
//
//		@AfterAll
//		static void tearDownAfterClass() throws Exception {
//		}
//
//		@Test
//		@Order(1)
//		@Rollback(false)
//		public void saveCorpTest() {
//
//			// actual result
//			accountRepository.save(c);
//
//			Assertions.assertNotNull(c.getAccNumber());
//
//		}
//
//	}
//}
